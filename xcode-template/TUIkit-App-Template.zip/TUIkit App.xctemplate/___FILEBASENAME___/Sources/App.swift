//
//  App.swift
//  ___VARIABLE_productName___
//

import TUIkit

/// The main TUIkit application.
@main
struct ___VARIABLE_productName:identifier___App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
