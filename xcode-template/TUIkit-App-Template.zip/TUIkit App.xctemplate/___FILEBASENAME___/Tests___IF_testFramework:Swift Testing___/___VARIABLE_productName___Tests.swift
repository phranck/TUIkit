import Testing
@testable import ___VARIABLE_productName___

@Test func example() async throws {
    #expect(true)
}
