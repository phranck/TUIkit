// swift-tools-version: 6.0

import PackageDescription

let package = Package(
    name: "___VARIABLE_productName___",
    platforms: [
        .macOS(.v15)
    ],
    dependencies: [
        .package(url: "https://github.com/phranck/TUIkit.git", branch: "main")___IF_includeSQLite___,
        .package(url: "https://github.com/stephencelis/SQLite.swift.git", from: "0.15.0")___ENDIF___
    ],
    targets: [
        .executableTarget(
            name: "___VARIABLE_productName___",
            dependencies: [
                .product(name: "TUIkit", package: "TUIkit")___IF_includeSQLite___,
                .product(name: "SQLite", package: "SQLite.swift")___ENDIF___
            ],
            path: "Sources"
        )___IF_testFramework:Swift Testing___,
        .testTarget(
            name: "___VARIABLE_productName___Tests",
            dependencies: ["___VARIABLE_productName___"],
            path: "Tests"
        )___ENDIF______IF_testFramework:XCTest___,
        .testTarget(
            name: "___VARIABLE_productName___Tests",
            dependencies: ["___VARIABLE_productName___"],
            path: "Tests"
        )___ENDIF___
    ]
)
