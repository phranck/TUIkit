import XCTest
@testable import ___VARIABLE_productName___

final class ___VARIABLE_productName___Tests: XCTestCase {
    func testExample() throws {
        XCTAssertTrue(true)
    }
}
